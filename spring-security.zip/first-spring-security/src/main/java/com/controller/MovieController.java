package com.controller;

import java.util.ArrayList;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MovieController {

	ArrayList al=new ArrayList();
	@PreAuthorize("hasAnyRole('USER','ADMIN')")
	@GetMapping("/show/movies")
	public ArrayList showMovies()
	{
		al.add("ABC Movie acted by abc person");
		al.add("xyz movie acted by xyz person");
		return al;
	}
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/add/movies")
	public String addMovies()
	{
		return "this mehtod contains"+"logic to add movie";
	}
}
