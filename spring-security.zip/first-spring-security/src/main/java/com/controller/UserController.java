package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.websocket.server.PathParam;

@RestController
public class UserController {

	@Autowired
	JdbcTemplate template;//any operation can be performed without creating any repository
@GetMapping("/disableusername/{username}")
//http:localhost:8080/disableusername/shree

	public String disableUser(@PathVariable("username")String name)
	{
		template.update("update users set enabled=false where username=?",name);
	
		return "updated sucessfully";
	}
}
