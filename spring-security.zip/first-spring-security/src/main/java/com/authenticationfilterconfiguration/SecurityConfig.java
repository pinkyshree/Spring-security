package com.authenticationfilterconfiguration;


import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
@Autowired
DataSource datasource;
	@Bean
	public SecurityFilterChain mySecurityFilter(HttpSecurity http) throws Exception
	{
		http.authorizeHttpRequests((requests)->requests.anyRequest().
				authenticated());
		http.formLogin();
		//http.httpBasic();
		http.csrf(csrf -> csrf.disable());
		http.headers(header->header.frameOptions(frame->frame.sameOrigin()));
		return http.build();
	}
//frames are used to display the parts of different framework	
	@Bean
	public JdbcUserDetailsManager createUsers()
	{
	//	UserDetails is a interface to create users
		UserDetails admin=User.withUsername("yuva")
		//.password("{noop}welcome@1234")
				.password(passwordEncoder().encode("welcome@1234"))//encode method will convert password to hash format and sent to passwordencider method
		.roles("ADMIN")
		.build();
		
		UserDetails user=User.withUsername("shree")
				//.password("{noop}welcome@1234")
				.password(passwordEncoder().encode("welcome@1234"))
				.roles("USER")
				.build();
		//we will store these users inside our computers memory
		
		//JdbcUserDetailsManager store the data in database
		
		JdbcUserDetailsManager manager=new JdbcUserDetailsManager(datasource);
		manager.createUser(user);
		manager.createUser(admin);
		return manager;
		//how to access the database h2/h2 console?,by url
		//jdbc:h2:mem:test
		//return new InMemoryUserDetailsManager(user,admin);
		}
	@Bean
	public BCryptPasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
}
